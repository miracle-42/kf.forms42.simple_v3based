export class Properties
{
    static username = "king_cath";
    static password = "2BOrNot2BKing?";
    static mailchimpapikey = "md-T8pDbN9W9AU6_Vc5CwupbQ";
    static testrecievername: string = "Cathrine Høyer";
    static testrecievermail: string = "allecalle@hotmail.com";
    static testauthoremail: string = "rob@kingfish.dk";
    static testauthorname: string = "Rob";
	static domain: string = "http://localhost:9002";
}
