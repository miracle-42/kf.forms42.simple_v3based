const instructors = "all_instructors";
const courses = "all_courses";
const weekoverview = "weekly_overview";
const courseactions = "course_actions";
const handlecourse = "handle_courses";

export {
    instructors,
    courses,
    weekoverview, 
    courseactions,
    handlecourse,
}