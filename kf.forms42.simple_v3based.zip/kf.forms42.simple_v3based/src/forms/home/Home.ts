import { Form } from "forms42core";

export class Home extends Form
{
    
    constructor(){
        super()
        // window.location.reload();
    }
}